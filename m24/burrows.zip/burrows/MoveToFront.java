import java.util.*;
import edu.princeton.cs.algs4.*;
public class MoveToFront {
    // apply move-to-front encoding, reading from standard input and writing to standard output
    public static void encode() {
    	LinkedList<Character> lt  = builddata();
    	while(!BinaryStdIn.isEmpty()) {
	    	char c = BinaryStdIn.readChar();
	    	byte index =(byte)lt.indexOf(c);
	    	BinaryStdOut.write(index);
	    	lt.addFirst(lt.remove(index));
	    }
	    BinaryStdOut.close();

    }
    public static LinkedList builddata() {
    	LinkedList<Character> lt = new LinkedList<Character>();  
    	for (int i =0;i < 256 ;i++) {
    		lt.add((char)i);
    	}
    	return lt;
    }
    // apply move-to-front decoding, reading from standard input and writing to standard output
    public static void decode() {
	    	LinkedList<Character> lt  = builddata();
    	while(!BinaryStdIn.isEmpty()) {
	    	int c = (int)BinaryStdIn.readChar();
	    	char ch = lt.get(c);
	    	lt.remove(c);
	    	lt.addFirst(ch);
	    	BinaryStdOut.write(ch);
    	}
    	BinaryStdOut.close();
    }

    // if args[0] is '-', apply move-to-front encoding
    // if args[0] is '+', apply move-to-front decoding
    public static void main(String[] args) {
    	if (args[0].equals("-")) {
    		encode();
    	}else if (args[0].equals("+")) {
    		decode();
    	}
    }
}