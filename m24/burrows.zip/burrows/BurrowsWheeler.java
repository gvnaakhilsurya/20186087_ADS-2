class BurrowsWheeler {

	public static void htransform(){
		String str= BinaryStdIn.readString();
		CircularSuffixArray cs = new CircularSuffixArray(str);
        String output = "";
        for (int i=0;i<cs.length();i++) {
            output+=str.charAt((cs.index(i) + cs.length()-1)%cs.length());
            if (cs.index(i) ==0) {
                BinaryStdOut.write(i);
            }
        }
        BinaryStdOut.write(output);
        BinaryStdOut.close();
    }
    public static void Ihtransform(){
        
    }


    public static void main(String[] args) {
    	if (args[0].equals("-")) {
    		htransform();
    	} else {
            Ihtransform();
        }
    }
}