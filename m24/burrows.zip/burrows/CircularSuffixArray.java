import java.util.Arrays;
import edu.princeton.cs.algs4.*;
public class CircularSuffixArray {
    CircularSuffix[] suffixes;
     String text;
     int first;

    /**
     * Initializes a suffix array for the given {@code text} string.
     * @param text the input string
     */
    public CircularSuffixArray(String text) {
        if (text == null) {
            throw new IllegalArgumentException();
        }
        int n = text.length();
        this.text = text;
        suffixes = new CircularSuffix[n];
        for (int i = 0; i < n; i++)
            suffixes[i] = new CircularSuffix(i);
        Arrays.sort(suffixes);
    }

   public  class CircularSuffix implements Comparable<CircularSuffix> {
       public final int index;

       public CircularSuffix( int index) {
            //this.text = text;
            this.index = index;
        }
       public int length() {
            return text.length();
        }
       public char charAt(int i) {
            i = (index + i)%length();
            return text.charAt(i);
        }

        public int compareTo(CircularSuffix that) {
            if (this == that) return 0;  // optimization
            int n = Math.min(this.length(), that.length());
            for (int i = 0; i < n; i++) {
                if (this.charAt(i) < that.charAt(i)) return -1;
                if (this.charAt(i) > that.charAt(i)) return +1;
            }
            return this.length() - that.length();
        }

        public String toString() {
            return text.substring(index) + text.substring(0,index);
        }
    }

    /**
     * Returns the length of the input string.
     * @return the length of the input string
     */
    public  int length() {
        return suffixes.length;
    }


    /**
     * Returns the index into the original string of the <em>i</em>th smallest suffix.
     * That is, {@code text.substring(sa.index(i))} is the <em>i</em>th smallest suffix.
     * @param i an integer between 0 and <em>n</em>-1
     * @return the index into the original string of the <em>i</em>th smallest suffix
     * @throws java.lang.IllegalArgumentException unless {@code 0 <= i < n}
     */
    public int index(int i) {
        if (i < 0 || i >= suffixes.length) throw new IllegalArgumentException();
        return suffixes[i].index;
    }

    /**
     * Unit tests the {@code SuffixArray} data type.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        String input = StdIn.readString();
        CircularSuffixArray cs = new CircularSuffixArray(input);
        System.out.println("length is " + cs.length());
        for (int i = 0; i < cs.length(); i++) {
            int index = cs.index(i);
            StdOut.printf("%3d : %3d\n", i, index);
        }
        
    }

}
